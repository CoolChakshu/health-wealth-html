 <!doctype html>
<html class="no-js" lang="zxx">

<!-- Mirrored from ecologytheme.com/theme/travelstar/index-3.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:32:29 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="TravelStar - Tour, Travel, Travel Agency Template">
    <meta name="keywords" content="Tour, Travel, Travel Agency Template">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelStar - Tour, Travel & Travel Agency Template</title>
    <!-- Google Fonts Includes -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <!-- Favi icon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/images/favicon.ico">
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="css/assets/bootstrap.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="css/assets/animate.css">
    <!-- Button Hover animate css -->
    <link rel="stylesheet" href="css/assets/hover-min.css">
    <!-- jquery-ui.min css -->
    <link rel="stylesheet" href="css/assets/jquery-ui.min.css">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="css/assets/meanmenu.min.css">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="css/assets/owl.carousel.min.css">
    <!-- slick css -->
    <link rel="stylesheet" href="css/assets/slick.css">
    <!-- customselect.min-->
    <link rel="stylesheet" href="css/assets/jquery-customselect.css">
    <!-- select2.min-->
    <link rel="stylesheet" href="css/assets/select2.min.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="css/assets/font-awesome.min.css">
    <!-- magnific Css -->
    <link rel="stylesheet" href="css/assets/magnific-popup.css">
    <!-- Revolution Slider -->
    <link rel="stylesheet" href="css/assets/revolution/layers.css">
    <link rel="stylesheet" href="css/assets/revolution/navigation.css">
    <link rel="stylesheet" href="css/assets/revolution/settings.css">
    <!-- Preloader css -->
    <link rel="stylesheet" href="css/assets/preloader.css"> 
    
    <link rel="stylesheet" href="css/style.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/master.css">
    <!-- modernizr css -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>  
<div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>  
<!-- header area start here -->
<?php include ('header.php');?>
<!-- header area end here -->
<!-- header area end here -->


<section class="popular-packages" id="popular_packages_3">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-title">
                    <h2>Our Most Popular Packges</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/1.jpg" alt=""></a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Dubai – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/2.jpg" alt=""></a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Thailand – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/3.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">England – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/4.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Italy – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/5.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Brazil – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/6.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">India – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->
        </div>
    </div>
</section> <!--end  popular packajge -->


<!-- Choose Travelstar version two start  -->
<section class="choose-travelstar-version-2">
    <div class="ImageBlock ImageBlock--switch">
        <div class="container-fluid">
            <div class="row pt-100 pb-65">
                <div class="col-12 col-lg-6 col-md-12 col-sm-12 ImageBlock--switch-tab ">
                    <div class="section-title-3">
                        <h2>Why Choose travlestar</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet.</p>
                    </div>
                    <!-- single -traverls -->
                    <div class="row travel-lp">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="single-travel">
                                <div class="media">
                                    <div class="media-body travel-content">
                                        <h4>Travel Arrangements</h4>
                                        <p>Lorem ipsum dolor sit amet consect adiu piscing elit sed diam nonum euismo tincidunt ut.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="single-travel">
                                <div class="media">
                                    <div class="media-body travel-content">
                                        <h4>Cheap Flights</h4>
                                        <p>Lorem ipsum dolor sit amet consect adiu piscing elit sed diam nonum euismo tincidunt ut.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row travel-lp">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="single-travel">
                                <div class="media">
                                    <div class="media-body travel-content">
                                        <h4>Hand-picked tours</h4>
                                        <p>Lorem ipsum dolor sit amet consect adiu piscing elit sed diam nonum euismo tincidunt ut.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="single-travel">
                                <div class="media">
                                    <div class="media-body travel-content">
                                        <h4>Best Price Guarantee</h4>
                                        <p>Lorem ipsum dolor sit amet consect adiu piscing elit sed diam nonum euismo tincidunt ut.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> <!-- single -traverls -->
                </div>
            </div>
        </div>

        <div class="ImageBlock__image col-md-6 col-sm-6 ImageBlock--switch-img">
            <div class="ImageBackground">
                <div class="ImageBackground__holder">
                    <img src="images/bgimage/long.jpg" alt="" />
                </div>
            </div>
        </div><!-- right side image -->
    </div>
</section><!-- Choose Travelstar version two end -->









    <!-- discount & deals section start here -->
    <section class="discoun_deal section-paddings">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title">
                        <h2>Discount & Deals</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- single dicount -->
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 single-item">
                    <div class="single-discount-deal">
                        <figure>
                            <img src="images/destination/pd1.jpg" alt="">
                            <figcaption>
                                <div class="offer-content">
                                    <span class="offer_btn">40% off</span>
                                    <div class="offer_details">
                                        <h3><img src="images/icon/map.png" alt="" class="map_icon">London, Eangland</h3>
                                        <ul class="tower-bridge d-flex justify-content-between">
                                            <li>London Bridge</li>
                                            <li>3 Tours</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="travel-book-btn">
                                    <a href="#" class="travel-booking-btn hvr-fade">Book Now</a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                </div><!--end single dicount -->

                <div class="col-12 col-sm-6 col-md-6 col-lg-3 single-item">
                    <div class="single-discount-deal">
                        <figure>
                            <img src="images/destination/pd2.jpg" alt="">
                            <figcaption>
                                <div class="offer-content">
                                    <span class="offer_btn">30% off</span>
                                    <div class="offer_details">
                                        <h3><img src="images/icon/map.png" alt="" class="map_icon">Rome, Itally</h3>
                                        <ul class="tower-bridge d-flex justify-content-between">
                                            <li>Collosiam</li>
                                            <li>3 Tours</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="travel-book-btn">
                                    <a href="#" class="travel-booking-btn hvr-fade">Book Now</a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                </div><!--end single dicount -->

                <div class="col-12 col-sm-6 col-md-6 col-lg-3 single-item">
                    <div class="single-discount-deal">
                        <figure>
                            <img src="images/destination/pd3.jpg" alt="">
                            <figcaption>
                                <div class="offer-content">
                                    <span class="offer_btn">50% off</span>
                                    <div class="offer_details">
                                        <h3><img src="images/icon/map.png" alt="" class="map_icon">Dilli, India</h3>
                                        <ul class="tower-bridge d-flex justify-content-between">
                                            <li>India Gate</li>
                                            <li>3 Tours</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="travel-book-btn">
                                    <a href="#" class="travel-booking-btn hvr-fade">Book Now</a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                </div><!--end single dicount -->              

                <div class="col-12 col-sm-6 col-md-6 col-lg-3 single-item">
                    <div class="single-discount-deal">
                        <figure>
                            <img src="images/destination/pd4.jpg" alt="">
                            <figcaption>
                                <div class="offer-content">
                                    <span class="offer_btn">20% off</span>
                                    <div class="offer_details">
                                        <h3><img src="images/icon/map.png" alt="" class="map_icon">Paris, Franch</h3>
                                        <ul class="tower-bridge d-flex justify-content-between">
                                            <li>Iffel Tower</li>
                                            <li>3 Tours</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="travel-book-btn">
                                    <a href="#" class="travel-booking-btn hvr-fade">Book Now</a>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                </div><!--end single dicount -->
            </div>
        </div>
    </section> <!-- discount & deals section end here here -->

<section class="video-play video-play-3">
    <div class="video-content">
        <div class="section-title">
            <h2>Discover The World</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
        </div>
        <div class="video-play-btn">
            <a href="https://www.youtube.com/watch?v=ZZ9E-Jadv88" class="video_iframe"><i class="fa fa-play"></i></a><h6>Just 5 minutes</h6>
        </div>
    </div>
</section><!-- video area end  here -->



<!-- guide and Expert Advice strat -->
<section class="section-paddings">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-title text-center">
                    <h2>Travel guide and Expert Advice</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- single travel blog-->
            <div class="col-12 col-sm-6 col-md-6 col-lg-4 phone-layout-s">
                <div class="single-travel-blog">
                    <div class="blog-image">
                        <a href="#"><img src="images/blog/1.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">
                            <div class="post-date">
                                <span>12 July, 2019</span>
                            </div>
                            <ul class="post-social">
                                <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                </li>
                                <li><a href="#"><i class="fa fa-heart-o"></i>43</a>
                                </li>
                            </ul>
                        </div>
                        <div class="blog-post-content">
                            <h4><a href="#" title="">Tips for taking a long-term trip with kids.</a></h4>
                            <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div> <!--end single travel guide & security-->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4 phone-layout-s">
                <div class="single-travel-blog">
                    <div class="blog-image">
                        <a href="#"><img src="images/blog/2.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">
                            <div class="post-date">
                                <span>12 July, 2019</span>
                            </div>
                            <ul class="post-social">
                                <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                </li>
                                <li><a href="#"><i class="fa fa-heart-o active"></i>43</a>
                                </li>
                            </ul>
                        </div>
                        <div class="blog-post-content">
                            <h4><a href="#" title="">Tips for taking a long-term trip with kids.</a></h4>
                            <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div> <!--end single travel guide & security-->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4 phone-layout-s">
                <div class="single-travel-blog">
                    <div class="blog-image">
                        <a href="#"><img src="images/blog/3.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">
                            <div class="post-date">
                                <span>12 July, 2019</span>
                            </div>
                            <ul class="post-social">
                                <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                </li>
                                <li><a href="#"><i class="fa fa-heart-o"></i>43</a>
                                </li>
                            </ul>
                        </div>
                        <div class="blog-post-content">
                            <h4><a href="#" title="">Tips for taking a long-term trip with kids.</a></h4>
                            <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div> <!-- single travel guide & security end-->
        </div>
    </div>
</section> <!--End guide and Expert Advice strat -->






<!-- Choose Travelstar version two start  -->
<section class="choose-travelstar-version-2 thailand-trip">
    <div class="ImageBlock ImageBlock--switch">
        <div class="ImageBlock__imagecol-12 col-lg-6 col-md-12 col-sm-12">
            <div class="ImageBackground">
                <div class="ImageBackground__holder">
                    <img src="images/bgimage/long2.jpg" alt="" />
                    <div class="starting">
                        <div class="starting-elemnts">
                            <p>Starting at</p>
                            <span>$325</span>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--End Travelstar left image -->

        <div class="container">
            <div class="row ml-auto">
                <div class="col-12 col-lg-6 col-md-12 col-sm-12 ml-auto">
                    <div class="trip_discripton_wrapper">
                        <div class="section-title-3">
                            <h2>Explore the Thailand Trip</h2>
                        </div>
                        <div class="thailand-description">
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismody tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim adi minim veniam, qu nostrud exerci tation dolore magna aliquam erat volutpat.</p>

                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit yoused diam nonummy nibh euismody tincidunt ut laoreet dolore magna.</p>
                            <a href="#" class=" thailan-btn travel-primary-btn  hvr-shutter-out-horizontal">Book Now</a>
                        </div><!--end single travel -->
                    </div>
                </div>
            </div>
        </div><!-- Travelstar right side content-->
    </div>
</section><!-- Choose Travelstar version two end -->




<!-- testimonial area start here -->
<section class="section-paddings testimonial-two">
    <div class="testimonial-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2>What Our Happy Travelers Say</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <!-- start top media -->
                    <div class="top-testimonial-image slick-pagination">
                        <div class="carousel-images slider-nav-two">
                            <div class="images_single"><img src="images/client/3.jpg" alt="1" class="img-responsive img-circle"></div>
                            <div class="images_single"><img src="images/client/9.jpg" alt="3" class="img-responsive img-circle"></div>
                            <div class="images_single"><img src="images/client/6.jpg" alt="2" class="img-responsive img-circle"></div>
                            <div class="images_single"><img src="images/client/9.jpg" alt="3" class="img-responsive img-circle"></div>
                        </div>
                    </div><!-- end top media images -->

                    <!-- bottom testimonial message -->
                    <div class="block-text">
                        <div class="carousel-text slider-for-two">
                            <div class="single-box">
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt utrinyi dolore magna aliquam erat volutpat Upt wisi enimbf adiminim veniamp nostrud exer tatjhion ullamc orperea commodo consequ euismod laoreet dolore magna.
                                </p>
                                <div class="client-bio">
                                    <h3>Jhonthan Smith</h3>
                                    <span>London Trip Traveler</span>
                                </div>
                                <ul class="rating d-flex justify-content-center">
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                </ul>
                            </div>
                            <div class="single-box">
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt utrinyi dolore magna aliquam erat volutpat Upt wisi enimbf adiminim veniamp nostrud exer tatjhion ullamc orperea commodo consequ euismod laoreet dolore magna.
                                </p>
                                <div class="client-bio">
                                    <h3>Oscar Charls</h3>
                                    <span>Martin, Parent</span>
                                </div>
                                <ul class="rating d-flex justify-content-center">
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                </ul>
                            </div>
                            <div class="single-box">
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt utrinyi dolore magna aliquam erat volutpat Upt wisi enimbf adiminim veniamp nostrud exer tatjhion ullamc orperea commodo consequ euismod laoreet dolore magna.
                                </p>
                                <div class="client-bio">
                                    <h3>Oscar Charls</h3>
                                    <span>Martin, Parent</span>
                                </div>
                                <ul class="rating d-flex justify-content-center">
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                </ul>
                            </div>
                            <div class="single-box">
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt utrinyi dolore magna aliquam erat volutpat Upt wisi enimbf adiminim veniamp nostrud exer tatjhion ullamc orperea commodo consequ euismod laoreet dolore magna.
                                </p>
                                <div class="client-bio">
                                    <h3>Oscar Charls</h3>
                                    <span>Martin, Parent</span>
                                </div>
                                <ul class="rating d-flex justify-content-center">
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                    <li><i class="fa fa-star"></i></li>                                    
                                </ul>
                            </div>
                        </div>
                    </div><!-- bottom testimonial message -->
                </div><!-- /.block-text -->
            </div>
        </div>
    </div>
</section><!-- testimonial area end here -->






<section class="section-paddings our_partners">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-title text-center">
                    <h2>Our Trusted Partners</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- partners images -->
            <div class="partner-slider-active owl-carousel">
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/1.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/2.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/3.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/4.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/5.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- partners images -->
        <div class="row">
            <!-- partners images -->
            <div class="partner-slider-active owl-carousel">
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/1.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/2.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/3.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/4.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/5.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>  <!-- end partners images -->
    </div>
</section> <!--end partner section -->



<?php include ('footer.php');?><!-- end footer -->

    <div class="to-top pos-rtive">
        <a href="#"><i class = "fa fa-angle-up"></i></a>
    </div><!-- Scroll to top jump button end-->

    <!-- ============================
            JavaScript Files
    ============================= -->

    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.0.min.js"></script>
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>  
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- owl.carousel js -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- slick js -->
    <script src="js/slick.min.js"></script>
    <!-- meanmenu js -->
    <script src="js/jquery.meanmenu.min.js"></script>
    <!-- jquery-ui js -->
    <script src="js/jquery-ui.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- counter js -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- Countdown js -->
    <script src="js/jquery.countdown.min.js"></script>
    <!-- waypoints js -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- Isotope js -->
    <script src="js/isotope.pkgd.min.js"></script>
    <!-- magnific js -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Image loaded js -->
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- chossen js -->
    <script src="js/chosen.jquery.min.js"></script>
    <script src="js/assets/revolution/jquery.themepunch.revolution.min.js"></script>
    <script src="js/assets/revolution/jquery.themepunch.tools.min.js"></script>
    <!-- Revolution Extensions -->
    <script src="js/assets/revolution/extensions/revolution.extension.actions.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.carousel.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.migration.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.navigation.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.parallax.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.slideanims.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.video.min.js"></script> 
    <script src="js/assets/revolution/revolution.js"></script>       
    <!-- Jquery plugin -->
    <script src="js/plugins.js"></script>
    <!-- select2 js plugin -->
    <script src="js/select2.min.js"></script>    
    <script src="js/colors.js"></script>
    <!-- Jquery plugin -->
    <script src="js/jquery-customselect.js"></script>
    <!-- main js -->
    <script src="js/custom.js"></script>
</body>


<!-- Mirrored from ecologytheme.com/theme/travelstar/index-3.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:32:31 GMT -->
</html>
