<!DOCTYPE html>
<html class="no-js" lang="zxx">

<!-- Mirrored from ecologytheme.com/theme/travelstar/package-version-one.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:33:36 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="TravelStar - Tour, Travel, Travel Agency Template">
    <meta name="keywords" content="Tour, Travel, Travel Agency Template">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelStar - Tour, Travel & Travel Agency Template</title>
    <!-- Google Fonts Includes -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <!-- Favi icon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/images/favicon.ico">
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="css/assets/bootstrap.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="css/assets/animate.css">
    <!-- Button Hover animate css -->
    <link rel="stylesheet" href="css/assets/hover-min.css">
    <!-- jquery-ui.min css -->
    <link rel="stylesheet" href="css/assets/jquery-ui.min.css">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="css/assets/meanmenu.min.css">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="css/assets/owl.carousel.min.css">
    <!-- slick css -->
    <link rel="stylesheet" href="css/assets/slick.css">
    <!-- chosen.min-->
    <link rel="stylesheet" href="css/assets/jquery-customselect.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="css/assets/font-awesome.min.css">
    <!-- magnific Css -->
    <link rel="stylesheet" href="css/assets/magnific-popup.css">
    <!-- Preloader css -->
    <link rel="stylesheet" href="css/assets/preloader.css"> 
    <!-- custome css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/master.css">
    <!-- modernizr css -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>     
<div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- header area start here -->
<!-- header area start here -->
<?php include ('header.php');?>
<!-- header area end here -->


<section class="breadcrumb-blog-version-one">
    <div class="single-bredcurms" style="background-image:url('images/bercums/package-Version-01.jpg');">
       <div class="container">
           <div class="row">
               <div class="col-sm-12 col-md-12">
                    <div class="bredcrums-content">
                        <h2>Package One</h2>
                        <ul>
                            <li><a href="index-2.php">Home</a></li>
                            <li class="active"><a href="package-version-one.php">Package Style One</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!-- blog breadcrumb version one end here -->


<section class="popular-packages">
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/1.jpg" alt=""></a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Dubai – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/2.jpg" alt=""></a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Thailand – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/3.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">England – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/4.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Italy – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/5.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Brazil – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/6.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">India – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->            

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/1.jpg" alt=""></a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Dubai – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/2.jpg" alt=""></a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Thailand – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/3.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">England – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->
        </div>
        <div class="row pagination_wrapper">
            <div class="col-sm-12 text-center">
                <ul class="pagination">
                    <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>                    
                    <li><a href="#"><i class="fa fa-chevron-right"></i></a></li>
                </ul>
            </div><!-- pagination end here -->
        </div>
    </div>
</section> <!--end  popular packajge -->





<?php include ('footer.php');?> <!-- end footer -->

<div class="to-top pos-rtive">
    <a href="#"><i class = "fa fa-angle-up"></i></a>
</div><!-- Scroll to top-->

    <!-- ============================
            JavaScript Files
    ============================= -->

    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.0.min.js"></script>
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>  
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- owl.carousel js -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- slick js -->
    <script src="js/slick.min.js"></script>
    <!-- meanmenu js -->
    <script src="js/jquery.meanmenu.min.js"></script>
    <!-- jquery-ui js -->
    <script src="js/jquery-ui.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- counter js -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- Countdown js -->
    <script src="js/jquery.countdown.min.js"></script>
    <!-- waypoints js -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- Isotope js -->
    <script src="js/isotope.pkgd.min.js"></script>
    <!-- magnific js -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Image loaded js -->
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- chossen js -->
    <script src="js/chosen.jquery.min.js"></script>  
    <!-- Jquery plugin -->
    <script src="js/plugins.js"></script>
    <!-- select2 js plugin -->
    <script src="js/select2.min.js"></script>    
    <script src="js/colors.js"></script>
    <!-- Jquery plugin -->
    <script src="js/jquery-customselect.js"></script>
    <!-- main js -->
    <script src="js/custom.js"></script>
</body>

<!-- Mirrored from ecologytheme.com/theme/travelstar/package-version-one.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:33:36 GMT -->
</html>
