<?php

$result="";

$servername="localhost";
$username="root";
$password="";
$database_name="mailer";

$connect=mysqli_connect($servername,$username,$password,$database_name);
if($connect)
{
  


if(isset($_POST['submit']))
{

$name=$_POST['name'];
$email=$_POST['email'];
$subject=$_POST['subject'];
$message=$_POST['message'];

$query="insert into gmaildb(name,email,subject,message) values ('$name','$email','$subject','$message')";
 
if(mysqli_query($connect,$query))
{
    echo "sucess";
}
    else
    {
    echo "fail";
    }
}
}


    require 'gmail/PHPMailerAutoload.php';
$mail=new PHPMailer;
$mail->isSMTP();   
$mail->Host='smtp.gmail.com';
$mail->Port= 25;
$mail->SMTPAuth=true;
$mail->SMTPSecure='tls';
$mail->Username='aishwaryapandey567@gmail.com';
$mail->Password='pandey9675589947';


$mail->setFrom($_POST['email'],$_POST['name']);
$mail->addAddress('aishwarya.pandey.ec.2014@miet.ac.in');
$mail->addReplyTo($_POST['email'],$_POST['name']);


$mail->isHTML(true);
$mail->Subject='Form Submission: '.$_POST['subject'];
$mail->Body='<h1 align=center> Name:'.$_POST['name'].'<br>Email:'.$_POST['email'].'<br>Message:'.$_POST['msg'].'</h1>';


if(!$mail->send())
{
    $result="error";
}
else
{
    $result="Congratulation party";
}


$servername="localhost";
$username="root";
$password="";
$database_name="mailer";

$connect=mysqli_connect($servername,$username,$password,$database_name);
if($connect)
{
  
}
else{
    echo "error";
}







?>
<html>
<head>
<title>PHP Contact Form</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
    <div class="form-container">
        <form  id="" method="post"
            action="" 
          >

<div>

<p><?php echo $result; ?> </p>

</div>


            <div class="input-row">
                <label style="padding-top: 20px;">Name</label> <span
                    id="userName-info" class="info"></span><br /> <input
                    type="text" class="input-field" name="name"
                    id="userName" />
            </div>



            <div class="input-row">
                <label>Email</label> <span id="userEmail-info"
                    class="info"></span><br /> 
                    <input type="text" class="input-field" name="email" id="userEmail" />
            </div>

            <!-- <div class="input-row">
                <label>subject</label> <span id="subject-info"
                    class="info"></span><br /> 
<input type="text" name="subject" placeholder="subject">
</div> -->






            <div class="input-row">
                <label>Subject</label> <span id="subject-info"
                    class="info"></span><br /> 
                    <input type="text" class="input-field" name="subject" id="subject" />
            </div>



            <div class="input-row">
                <label>Message</label> <span id="userMessage-info"
                    class="info"></span><br />
                <textarea name="message" id="content" class="input-field" cols="60" rows="6"></textarea>
            </div>



            <div>
                <input type="submit" name="submit" class="btn-submit"
                    value="Send" />

        
            </div>
        </form>
    </div>