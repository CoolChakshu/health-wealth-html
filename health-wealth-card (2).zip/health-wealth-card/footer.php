
<html>
<head>

</head>

<body>
<footer class="footer-area">
    <div class="container">
        <div class="row">
            <!-- footer left -->
            <div class="col-md-3 col-sm-6">
                <div class="single-footer">
                    <div class="footer-title">
                        <h3><a href="home.php"><img src="images/logo.png" alt=""></a></h3>
                    </div>
                    <div class="footer-left">
                        <div class="footer-logo">
                            <p>Lorem ipsum dolor sit amet conset ctetur adipiscin elit Etiam at ipsum at ligula vestibulum sodales.</p>
                        </div>
                        <ul class="footer-contact">
                            <li id="MybtnModal" style=""><img class="map" src="images/icon/map.png"  alt=""><a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.499046734415!2d77.3138693148381!3d28.584801982436606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce458c5170c81%3A0x931a76bc3bfae16a!2sDesire+IT+Solutions+Pvt+Ltd.!5e0!3m2!1sen!2sin!4v1523822882952" >B - 131 Ground Floor ,Noida Sector - 02, Uttar Pradesh</a> </li>
                            <li><img class="map" src="images/icon/phone.png" alt=""><a href="tel:+91-0120-415741" >+91-0120-415741</a></li>
                            <li><img class="map" src="images/icon/gmail.png" alt="">info@desireispl.com</li>
                        </ul>
                    </div>
                </div>
            </div> <!-- footer left -->

            <!-- footer destination -->
            <div class="col-md-2 col-sm-6">
                <div class="single-footer">
                    <div class="footer-title">
                        <h3>Quick Link</h3>
                    </div>
                    <ul class="list-unstyled">
                        <li><a href="#" title="">Home</a></li>
                        <li><a href="#" title="">About</a></li>
                        <li><a href="#" title="">Our Network</a></li>
                        <li><a href="#" title="">Services</a></li>

                        <!-- <li><a href="#" title="">Hotels</a></li>
                        <li><a href="#" title="">Flights</a></li>
                        <li><a href="#" title="">Blog</a></li>
                        <li><a href="#" title="">Pages</a></li> -->
                        <li><a href="#" title="">Contact</a></li>
                    </ul>
                </div>
            </div>  <!-- footer destination -->

            <div class="col-md-4 col-sm-6">
                <div class="single-footer">
                    <div class="single-recent-post">
                        <div class="footer-title">
                            <h3>Recent News</h3>
                        </div>
                        <ul class="list-unstyled">
                        <li><a href="#" title="">Home</a></li>
                        <li><a href="#" title="">About</a></li>
                        <li><a href="#" title="">Our Network</a></li>
                        <li><a href="#" title="">Services</a></li>

                        <!-- <li><a href="#" title="">Hotels</a></li>
                        <li><a href="#" title="">Flights</a></li>
                        <li><a href="#" title="">Blog</a></li>
                        <li><a href="#" title="">Pages</a></li> -->
                        <li><a href="#" title="">Contact</a></li>
                            </ul>
                    </div>
                </div>
            </div>  <!-- footer latest news -->

            <!-- footer contact -->
            <div class="col-md-3 col-sm-6 f-phone-responsive">
                <div class="single-footer">
                    <div class="footer-title">
                        <h3>Quick Contact</h3>
                    </div>
                    <div class="footer-contact-form">
                        <form action="#">
                            <ul class="footer-form-element">
                                <li>
                                    <input type="text" name="email" id="email" placeholder="" value="Email Address" onblur="if(this.value==''){this.value='Email Address'}" onfocus="if(this.value=='Email Address'){this.value=''}">
                                </li>
                                <li class="text_area">
                                    <textarea name="message" id="message" cols="30" rows="10" placeholder="Message"></textarea>
                                    <button type="submit">Send</button>
                                </li>
                                <li>
                                    
                                </li>
                            </ul>
                        </form>
                    </div>
                    <div class="footer-social-media">
                        <div class="social-footer-title">
                            <h3>Follow Us</h3>
                        </div>
                        <ul class="footer-social-link">
                            <li class="facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li class="twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li class="linkedin"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li class="gplus"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li class="youtube"><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>  <!-- footer contact -->
        </div>
    </div>
    <div class="footer_bottom_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12">
                    <div class="copy_right_wrapper">
                        <div class="copyright">
                            <p>Copyright &copy; 2019 Desire Health Wealth Card </p>
                        </div>
                        <ul class="payicon pull-right">
                            <li>We Accept : </li>
                            <li><a href="#" title=""><img src="images/payicon01.png" alt=""></a></li>
                            <li><a href="#" title=""><img src="images/payicon02.png" alt=""></a></li>
                            <li><a href="#" title=""><img src="images/payicon03.png" alt=""></a></li>
                            <li><a href="#" title=""><img src="images/payicon04.png" alt=""></a></li>
                            <li><a href="#" title=""><img src="images/payicon05.png" alt=""></a></li>
                            <li><a href="#" title=""><img src="images/payicon06.png" alt=""></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<script language="JavaScript" type="text/javascript" src="/js/jquery-1.2.6.min.js"></script>
<script language="JavaScript" type="text/javascript" src="/js/jquery-ui-personalized-1.5.2.packed.js"></script>
<script language="JavaScript" type="text/javascript" src="/js/sprinkle.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js">
</script>

<script>
$(document).ready(function(){
	$('#MybtnModal').click(function(){
  		$('#Mymodal').show();
	});
});
</script>
<!-- <button type="button" id="MybtnModal" class="btn btn-primary">Open Modal Using jQuery</button> -->
<!-- <div class="row">
<div class="col-md-12" id="Mymodal">
    
</div>
</div> -->
<!-- <div id="googleMap" style="width:100%;height:400px;"></div>

 <script>
function myMap() {
var mapProp= {
  center:new google.maps.LatLng(51.508742,-0.120850),
  zoom:5,
};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
}
</script>

<script src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.499046734415!2d77.3138693148381!3d28.584801982436606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce458c5170c81%3A0x931a76bc3bfae16a!2sDesire+IT+Solutions+Pvt+Ltd.!5e0!3m2!1sen!2sin!4v1523822882952" width="1349px;" height="450" frameborder="0" style="border:0" allowfullscreen></script> --> -->



<!-- <div class="row" id="Mymodal">
<div class="col-md-12">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.499046734415!2d77.3138693148381!3d28.584801982436606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce458c5170c81%3A0x931a76bc3bfae16a!2sDesire+IT+Solutions+Pvt+Ltd.!5e0!3m2!1sen!2sin!4v1523822882952" width="1349px;" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
</div> -->

</body>
</html>