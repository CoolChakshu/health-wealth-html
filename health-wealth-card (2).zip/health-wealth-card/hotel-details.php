<!DOCTYPE html>
<html class="no-js" lang="zxx">

<!-- Mirrored from ecologytheme.com/theme/travelstar/hotel-details.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:33:46 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="TravelStar - Tour, Travel, Travel Agency Template">
    <meta name="keywords" content="Tour, Travel, Travel Agency Template">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelStar - Tour, Travel & Travel Agency Template</title>
    <!-- Google Fonts Includes -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <!-- Favi icon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/images/favicon.ico">
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="css/assets/bootstrap.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="css/assets/animate.css">
    <!-- Button Hover animate css -->
    <link rel="stylesheet" href="css/assets/hover-min.css">
    <!-- jquery-ui.min css -->
    <link rel="stylesheet" href="css/assets/jquery-ui.min.css">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="css/assets/meanmenu.min.css">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="css/assets/owl.carousel.min.css">
    <!-- slick css -->
    <link rel="stylesheet" href="css/assets/slick.css">
    <!-- chosen.min-->
    <link rel="stylesheet" href="css/assets/jquery-customselect.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="css/assets/font-awesome.min.css">
    <!-- magnific Css -->
    <link rel="stylesheet" href="css/assets/magnific-popup.css">
    <!-- Preloader css -->
    <link rel="stylesheet" href="css/assets/preloader.css"> 
    <!-- custome css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/master.css">
    <!-- modernizr css -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>
<div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- header area start here -->
<!-- header area start here -->
<?php include ('header.php');?>
<!-- header area end here -->
 <!-- header area end here -->

<!-- blog breadcrumb version one strat here -->
<section class="breadcrumb-blog-version-one">
    <div class="single-bredcurms" style="background-image:url('images/bercums/Hotels-Version-02.jpg');">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="bredcrums-content">
                        <h2>Package</h2>
                        <ul>
                            <li><a href="index-2.php">Home</a>
                            </li>
                            <li class="active"><a href="single-package.php">Package Details</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!-- blog breadcrumb version one end here -->

<section class="section-paddings single-package-area" id="hotel_details">
    <div class="container">
        <div class="row">
            <!-- single package tab with details -->
            <div class="col-md-8 col-sm-12">
                <div class="single-package-details">
                    <div class="single-package-title">
                        <h2>Daydream Hotel</h2>
                    </div>
                    <ul class="package-content d-flex">
                        <li class="price_hotel"><span>50% /</span>Per Nights</li>
                        <li>
                            <span>
                               <i class="fa fa-star"></i>
                               <i class="fa fa-star"></i>
                               <i class="fa fa-star"></i>
                               <i class="fa fa-star"></i>
                               <i class="fa fa-star"></i>
                           </span>
                        </li>
                        <li>Code: 2451</li>
                    </ul>
                </div><!-- tab menu strat -->
                <div class="package_banner">
                    <img src="images/hotel/hotel01.jpg" alt="" class="img-fluid">
                </div>
                <div class="package-tab-menu">
                    <ul class="package-tab-menu nav nav-tabs" id="myTab2" role="tablist">
                        <li role="presentation"><a href="#description" class="active" aria-controls="description" role="tab" data-toggle="tab">Description</a></li>
                        <li role="presentation"><a href="#itinerary" aria-controls="itinerary" role="tab" data-toggle="tab">Tour Guide</a></li>
                        <li role="presentation"><a href="#map" aria-controls="map" role="tab" data-toggle="tab">Tour Map</a>
                        <li role="presentation"><a href="#video" aria-controls="video" role="tab" data-toggle="tab">Videos</a></li>
                        <li role="presentation"><a href="#reviews" aria-controls="reviews" role="tab" data-toggle="tab">Reviews</a></li>
                    </ul>
                </div><!-- tab menu end -->

                <!-- tab content start -->
                <div class="row">
                    <!-- tabs content -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade show active in" id="description">
                            <div class="row">
                                <!-- left content -->
                                <div class="col-md-12 col-sm-12">
                                    <div class="tour-description">
                                        <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight Japan Tripit territory international carren tal Pacific outdoor Turkey. Country international to urist attractions mil es train Moscow guide. Japan horse riding money Bacel ona Buda pest yach t passport animals package China hitchh iking discover deal. Russia St. Petersburg Cuba creditcard bookin g discover Amst erdam flying. Freedom ani mals car rental booki ng. GEO Instagram group discount Brasil Germany gateway activ e lifestyle. Transit sailing kayak diary Europe chartering.</p>
                                    </div>
                                    <div class="packaging_contents_wrapper">
                                        <h4>Why you chose this hotel</h4>
                                        <div class="packaging-contents">
                                            <ul class="list-unstyled">
                                                <li><i class="fa fa-angle-double-right"></i>Sed legere graecis ex.</li>
                                                <li><i class="fa fa-angle-double-right"></i>Airplane couchsurfing Moi.</li>
                                                <li><i class="fa fa-angle-double-right"></i>Tourist attractions people foreign</li>
                                            </ul>
                                            <ul class="list-unstyled packaging-contents-right pull-right">
                                                <li><i class="fa fa-angle-double-right"></i>ountry international to urist</li>
                                                <li><i class="fa fa-angle-double-right"></i>You need to be sure there isn't anything</li>
                                                <li><i class="fa fa-angle-double-right"></i>Airplane couchsurfing Moi.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div><!-- left-content -->

                            </div>
                        </div>

                        <div role="tabpanel" class="tab-pane fade" id="itinerary">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="tour-description">
                                        <h4>Tour Description</h4>
                                        <div class="main-timeline">
                                            <!-- single timeline -->
                                            <div class="timeline">
                                                <div class="timeline-content left">
                                                    <span class="timeline-icon">1</span>
                                                    <h4>Day 1: Meeting The All Members</h4>
                                                    <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight Japan Tripit territory international carren tal Pacific outdoor Turkey. Country international to urist attractions mil es train Moscow guide. Japan horse riding money Bacel ona Buda pest yach.</p>
                                                </div>
                                            </div><!-- single timeline -->

                                            <!-- single timeline -->
                                            <div class="timeline">
                                                <div class="timeline-content left">
                                                    <span class="timeline-icon">2</span>
                                                    <h4>Day 2: Unforgettable Journey</h4>
                                                    <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
                                                </div>
                                            </div><!-- single timeline -->

                                            <!-- single timeline -->
                                            <div class="timeline">
                                                <div class="timeline-content left">
                                                    <span class="timeline-icon">3</span>
                                                    <h4>Day 3: Night Party</h4>
                                                    <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
                                                </div>
                                            </div><!-- single timeline -->

                                            <!-- single timeline -->
                                            <div class="timeline">
                                                <div class="timeline-content left">
                                                    <span class="timeline-icon">4</span>
                                                    <h4>Day 4: Time To Say Good Bay</h4>
                                                    <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
                                                </div>
                                            </div><!-- single timeline -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div role="tabpanel" class="tab-pane fade" id="map">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="tour-description">
                                        <h4>Map Tour</h4>
                                        <!-- map -->
                                        <div class="mapp" id="overlay">
                                            <iframe id="maping" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3350.701132954845!2d-96.89708368545975!3d32.879626086054884!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864e9d666937c1f7%3A0xae26e896218f405!2sUSA+Bowl!5e0!3m2!1sbn!2sbd!4v1493296407400" allowfullscreen></iframe>
                                        </div><!-- map -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- video tab content start -->
                        <div role="tabpanel" class="tab-pane fade" id="video">
                            <div class="row">
                                <div class="col-12 col-md-12 col-sm-12">
                                    <div class="tour-description">
                                        <h4>Video</h4>
                                        <!-- Video -->
                                        <div class="tab-video-area video-bg">
                                            <div class="video-play-btn">
                                                <a href="https://www.youtube.com/watch?v=UQneDljrWm0" class="video_iframe"><span><i class="fa fa-play"></i></span></a>
                                            </div>
                                        </div><!-- Video -->
                                    </div>
                                </div>
                            </div>
                        </div><!-- video tab content end -->

                        <!-- video tab content start -->
                        <div role="tabpanel" class="tab-pane fade" id="reviews">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="tour-description">
                                         <div class="comment-list-items">
                                            <div class="comment-list-wrapper">
                                                <div class="comment-list">
                                                    <div class="commnet_img">
                                                        <img src="images/blog/comments1.jpg" alt="member img" class="img-fluid">
                                                    </div>
                                                    <div class="comment-text">
                                                        <div class="author_info"> 
                                                            <div class="author_name">
                                                                <a href="#" class="">Adam Smith</a> 
                                                                <span>20 July 2019 at 10.45 AM</span>
                                                             </div>
                                                             <div class="reply-comment">
                                                                <a href="#" title=""> <i class="flaticon-reply-arrow"></i> Reply</a>
                                                            </div> 
                                                        </div> 
                                                        <ul class="review_rating d-flex">
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                        </ul>    
                                                        <p>You need to be sure there isn't anything embarrassing hidden in the repeat predefined chunks as nessing hidden in the repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                                                    </div>
                                                </div>

                                                <div class="comment-list reply_comment_text">
                                                    <div class="commnet_img">
                                                       <img src="images/blog/comments2.jpg" alt="member img" class="img-fluid">
                                                    </div>
                                                    <div class="comment-text">
                                                        <div class="author_info"> 
                                                            <div class="author_name">
                                                                <a href="#" class="">Jonson Park</a> 
                                                                <span>20 July 2019 at 10.45 AM</span>
                                                             </div>
                                                             <div class="reply-comment">
                                                                <a href="#" title=""> <i class="flaticon-reply-arrow"></i> Reply</a>
                                                            </div> 
                                                        </div>
                                                        <ul class="review_rating d-flex">
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                        </ul>         
                                                        <p>You need to be sure there isn't anything embarrassing hidden in the repe essary, making this the first true generator on the Internet.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="comment-list-wrapper">
                                                <div class="comment-list">
                                                    <div class="commnet_img">
                                                        <img src="images/blog/comments1.jpg" alt="member img" class="img-fluid">
                                                    </div>
                                                    <div class="comment-text">
                                                        <div class="author_info"> 
                                                            <div class="author_name">
                                                                <a href="#" class="">Jonathon Smith</a> 
                                                                <span>20 July 2019 at 10.45 AM</span>
                                                             </div>
                                                             <div class="reply-comment">
                                                                <a href="#" title=""> <i class="flaticon-reply-arrow"></i> Reply</a>
                                                            </div> 
                                                        </div>
                                                        <ul class="review_rating d-flex">
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                            <li><i class="fa fa-star"></i></li>
                                                        </ul>         
                                                        <p>You need to be sure there isn't anything embarrassing hidden in the repeat predefined chunks as nessing hidden in the repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                                                    </div>                               
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div><!-- video tab content end -->
                    </div><!-- tabs content-->
                </div><!-- tab content end -->
            </div><!-- single package tab with details -->

            <!-- booking form start here -->
            <div class="col-md-4 col-sm-12">
                <aside>
                    <div class="booking-form">
                        <div class="booking-title">
                            <h2>Book This Tour</h2>
                            <p>Lorem ipsum dolor sit amet, consectet ur adipiscing elit, sedpr do eiusmod tempor incididunt ut.</p>
                        </div>
                        <form action="#" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" id="name" placeholder="Name">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" id="confirm_email" placeholder="E-mail">
                            </div>
                            <div class="form-group">
                                <input type="tel" class="form-control" id="number" placeholder="Phone Number">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="booking-date" placeholder="dd-mm-yy *">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="ticket" placeholder="Number Of Tickets *">
                            </div>
                            <div class="form-group">
                                <textarea name="messgae" id="message" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
                            </div>
                            <div class="form-group form_btn">
                                <button type="submit" class="booking-confirm hvr-shutter-out-horizontal">Book Now</button>
                            </div>
                        </form>
                    </div>
                </aside><!-- adverestment start here-->

                <div class="adding-form">
                    <div class="addfor-bg">
                        <div class="add-content">
                            <h3>Get A Question!</h3>
                            <p>Lorem ipsum dolor sit amet, consectet ur adipiscing elit, sedpr do eiusmod tempor incididunt ut.</p>
                            <ul class="contact-for-add">
                                <li><img src="images/icon/phone.png" alt="">+123-456-7890</li>
                                <li><img src="images/icon/gmail.png" alt="">info@yourcompany.com</li>
                            </ul>
                        </div>
                    </div>
                </div><!-- adverestment start here-->
            </div><!-- booking form end here -->
        </div>
    </div>
</section>

<?php include ('footer.php');?> <!-- end footer -->

<div class="to-top pos-rtive">
    <a href="#"><i class = "fa fa-angle-up"></i></a>
</div><!-- Scroll to top-->
    <!-- ============================
            JavaScript Files
    ============================= -->
    
    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.0.min.js"></script>
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>  
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- owl.carousel js -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- slick js -->
    <script src="js/slick.min.js"></script>
    <!-- meanmenu js -->
    <script src="js/jquery.meanmenu.min.js"></script>
    <!-- jquery-ui js -->
    <script src="js/jquery-ui.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- counter js -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- Countdown js -->
    <script src="js/jquery.countdown.min.js"></script>
    <!-- waypoints js -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- Isotope js -->
    <script src="js/isotope.pkgd.min.js"></script>
    <!-- magnific js -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Image loaded js -->
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- chossen js -->
    <script src="js/chosen.jquery.min.js"></script>  
    <!-- Jquery plugin -->
    <script src="js/plugins.js"></script>
    <!-- select2 js plugin -->
    <script src="js/select2.min.js"></script>    
    <script src="js/colors.js"></script>
    <!-- Jquery plugin -->
    <script src="js/jquery-customselect.js"></script>
    <!-- google map api -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIW0B_E3g-Yg533xy3yF0WHThi-mFvSNQ"></script>
    <!-- map js -->
    <script src="js/google-map.js"></script>
    <!-- main js -->    
    <script src="js/custom.js"></script>
</body>

<!-- Mirrored from ecologytheme.com/theme/travelstar/hotel-details.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:34:02 GMT -->
</html>
