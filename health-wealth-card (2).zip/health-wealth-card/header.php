<!-- header area start here -->
<header class="index-2">
    <div class="header_top_area">
        <div class="container">
            <div class="row">
                <div class="col-9 col-xs-6 col-sm-9 col-md-9 col-lg-9">
                    <div class="contact_wrapper_top">
                        <ul class="header_top_contact">
                            <li><i class="fa fa-phone" aria-hidden="true"></i><a href="tel: +91-0120-415741" style="color:white">+91-0120-415741</a> </li>
                            <li><i class="fa fa-envelope-o" aria-hidden="true"></i>info@desireispl.com</li>
                        </ul>
                        <div class="col-3 col-xs-3 col-sm-3 col-md-3 col-lg-3 offset-xs-4 ">
                        <button class="btn btn-success btn-md " style  data-ta-2rget="#myModalHorizontal">
                            Sign In
                        </button>
                        


                        <button class="btn btn-success btn-md" data-toggle="modal" data-target="#myModalHorizontal">
                            Login
                        </button>
                        </div>
                        
<!-- Modal -->
<div class="modal fade" id="myModalHorizontal" tabindex="-1" role="dialog" 
aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
   <div class="modal-content">
       <!-- Modal Header -->
       <div class="modal-header">
           <button type="button" class="close" 
              data-dismiss="modal">
                  <span aria-hidden="true">&times;</span>
                  <span class="sr-only">Close</span>
           </button>
        
       </div>
       
       <!-- Modal Body -->
       <div class="modal-body">
            <h1 class="text-center">Login</h1>
           <form class="form-horizontal" role="form">
             <div class="form-group">
               <label  class="col-sm-2 control-label"
                         for="inputEmail3">Email</label>
               <div class="col-sm-10">
                   <input type="email" class="form-control" 
                   id="Username" placeholder="Email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"/>
               </div>
             </div>
             <div class="form-group">
               <label class="col-sm-2 control-label"
                     for="inputPassword3" >Password</label>
               <div class="col-sm-10">
                   <input type="password" class="form-control"
                       id="Password" placeholder="Password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 5 or more characters"/>
               </div>
             </div>
             <div class="form-group">
                    <label class="col-sm-2 control-label"
                    for="inputPassword3" >User</label>
              <div class="col-sm-10">
                    <select class="form-control" id="sel1">
                            <option>Individual</option>
                            <option>DSA</option>
                         
                          </select>
              </div>
             </div>
             <div class="form-group">
               <div class="col-sm-offset-2 col-sm-10">
                 <button type="submit" class="btn btn-success">Sign in</button>
               </div>
             </div>
           </form>
           
           
           
           
           
           
       </div>
       
       <!-- Modal Footer -->
       <div class="modal-footer">
           <button type="button" class="btn btn-default"
                   data-dismiss="modal">
                       Close
           </button>
        
       </div>
   </div>
</div>
</div>






                    </div>
                </div>
            </div>
        </div>
    </div> <!-- header top end -->

    <div class="main_nav">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-2 col-xs-12 tap-v-responsive">
                    <div class="logo-area">
                        <a href="home.php"><img src="images/logo2.png" alt="">
                        </a>
                    </div>
                </div>
                <!-- main menu start here -->
                <div class="col-md-10">
                    <nav>
                        <ul class="main-menu text-right">
                            <li class="active"><a href="index-2.php">Home</a>
                             
                            </li>
                            <li><a href="single-package.php">About</a></li>
                            <!-- <li><a href="single-package.php">Buy Card</a></li> -->
                            <li><a href="hotel-version-one.php">Our Network</a></li>
                            
                            <li><a href="package-version-one.php">Services</a>
                                <ul class="dropdown">
                                    <li><a href="package-version-one.php">Package One</a></li>
                                    <li><a href="package-version-two.php">Package Two</a></li>
                                    <li><a href="single-package.php">Package Details</a></li>
                                </ul>
                            </li>
                       
                            <!-- <li><a href="#">Flights</a></li>
                            <li><a href="blog-version-one.php">Blog</a>
                                <ul class="dropdown">
                                    <li><a href="blog-version-one.php">Blog One</a></li>
                                    <li><a href="blog-version-two.php">Blog Two</a></li>
                                    <li><a href="blog-single.php">Blog Post</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Pages</a>
                                <ul class="dropdown">
                                    <li><a href="package-version-one.php">Package One</a></li>
                                    <li><a href="package-version-two.php">Package Two</a></li>
                                    <li><a href="single-package.php">single package</a></li>
                                    <li><a href="hotel-version-one.php">Hotel One</a></li>
                                    <li><a href="hotel-version-two.php">Hotel Two</a></li>
                                    <li><a href="blog-version-one.php">Blog One</a></li>
                                    <li><a href="hotel-version-two.php">Blog Two </a></li>
                                    <li><a href="blog-single.php">Single Blog</a></li>
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </li> -->
                         
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </nav>
                </div> <!-- main menu end here -->
            </div>
        </div>
    </div> <!-- header-bottom area end here -->
</header> <!-- header area end here -->