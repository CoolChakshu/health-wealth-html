<!DOCTYPE html>
<html class="no-js" lang="zxx">

<!-- Mirrored from ecologytheme.com/theme/travelstar/blog-version-one.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:34:02 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="TravelStar - Tour, Travel, Travel Agency Template">
    <meta name="keywords" content="Tour, Travel, Travel Agency Template">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelStar - Tour, Travel & Travel Agency Template</title>
    <!-- Google Fonts Includes -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <!-- Favi icon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/images/favicon.ico">
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="css/assets/bootstrap.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="css/assets/animate.css">
    <!-- Button Hover animate css -->
    <link rel="stylesheet" href="css/assets/hover-min.css">
    <!-- jquery-ui.min css -->
    <link rel="stylesheet" href="css/assets/jquery-ui.min.css">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="css/assets/meanmenu.min.css">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="css/assets/owl.carousel.min.css">
    <!-- slick css -->
    <link rel="stylesheet" href="css/assets/slick.css">
    <!-- chosen.min-->
    <link rel="stylesheet" href="css/assets/jquery-customselect.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="css/assets/font-awesome.min.css">
    <!-- magnific Css -->
    <link rel="stylesheet" href="css/assets/magnific-popup.css">
    <!-- Revolution Slider -->
    <link rel="stylesheet" href="css/assets/revolution/layers.css">
    <link rel="stylesheet" href="css/assets/revolution/navigation.css">
    <link rel="stylesheet" href="css/assets/revolution/settings.css">
    <!-- Preloader css -->
    <link rel="stylesheet" href="css/assets/preloader.css"> 
    <!-- custome css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/master.css">
    <!-- modernizr css -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>
<div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- header area start here -->
<!-- header area start here -->
<?php include ('header.php');?>
<!-- header area end here -->


<!-- blog breadcrumb version one strat here -->
<section class="breadcrumb-blog-version-one">
    <div class="single-bredcurms" style="background-image:url('images/bercums/Blogs-Version-01.jpg');">
       <div class="container">
           <div class="row">
               <div class="col-sm-12">
                 <div class="bredcrums-content">
                     <h2>Blog</h2>
                     <ul>
                        <li><a href="index-2.php">Home</a></li>
                        <li class="active"><a href="blog-version-two.php">Blog</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    </div>
</section><!-- blog breadcrumb version one end here -->


<section class="blog_wrapper">
    <div class="container">  
        <div class="row">        
            <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                <div class="single_blog">
                    <div class="blog_banner">
                        <a href="#" title=""><img src="images/blog/1.jpg" alt="" class="img-fluid"></a>
                    </div>
                    <div class="post_content_wrapper">
                        <div class="post_date"><p>Posted On : Feb 14 2019 - <span>Education Category</span></p></div>
                        <h3><a href="#" title="">Research of Learn training process</a></h3>
                        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                        <div class="post_by d-flex justify-content-between">
                            <a href="#" title="">Read More  <i class="flaticon-login-button"></i></a>
                        </div>        
                    </div>
                </div>                 

                <div class="single_blog">
                    <div class="blog_banner">
                        <a href="#" title=""><img src="images/blog/2.jpg" alt="" class="img-fluid"></a>
                    </div>
                    <div class="post_content_wrapper">
                        <div class="post_date"><p>Posted On : Feb 14 2019 - <span>Education Category</span></p></div>
                        <h3><a href="#" title="">Research of Learn training process</a></h3>
                        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                        <div class="post_by d-flex justify-content-between">
                            <a href="#" title="">Read More  <i class="flaticon-login-button"></i></a>
                        </div>             
                    </div>
                </div>                  
            

                <div class="single_blog">
                    <div class="blog_banner">
                        <a href="#" title=""><img src="images/blog/3.jpg" alt="" class="img-fluid"></a>
                    </div>
                    <div class="post_content_wrapper">
                        <div class="post_date"><p>Posted On : Feb 14 2019 - <span>Education Category</span></p></div>
                        <h3><a href="#" title="">Research of Learn training process</a></h3>
                        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                        <div class="post_by d-flex justify-content-between">
                            <a href="#" title="">Read More  <i class="flaticon-login-button"></i></a>
                        </div>              
                    </div>
                </div>  

                <div class="pagination_wrapper">
                    <ul class="pagination">
                        <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>                    
                        <li><a href="#"><i class="fa fa-chevron-right"></i></a></li>
                    </ul>
                </div>         
            </div> <!-- End Blog Right Side--->

            <div class="col-12 col-sm-12 col-md-4 col-lg-4 blog_wrapper_right ">
                <div class="blog-right-items">

                    <div class="search_blog widget_single">
                        <div class="form-full-box">
                            <form>
                                <div class="form-group">
                                    <input class="form-control" name="name" placeholder="Write Your Name" required="" type="text">
                                    <button class="register-btn" type="submit"><i class="fa fa-search"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>


                    <div class="recent_post_wrapper widget_single">
                        <div class="items-title">
                            <h3 class="title">Recent Post</h3>
                        </div>
                        <div class="single-post">
                            <div class="recent_img">
                                 <a href="#" title=""><img src="images/blog/f4.jpg" alt="" class="img-fluid"></a>
                            </div>
                            <div class="post_title">
                                <a href="#" title="">Research of Learn training process</a>
                                <div class="post-date">
                                    <span>May 29, 2019</span>
                                </div>
                            </div>
                        </div>

                        <div class="single-post">
                            <div class="recent_img">
                                <a href="#" title=""><img src="images/blog/f5.jpg" alt="" class="img-fluid"></a>
                            </div>
                            <div class="post_title">
                                <a href="#" title="">How to Become Master In CSS within a Week.</a>
                                <div class="post-date">
                                    <span>25 August, 2019</span>
                                </div>
                            </div>
                        </div>

                        <div class="single-post">
                            <div class="recent_img">
                                <a href="#" title=""><img src="images/blog/f6.jpg" alt="" class="img-fluid"></a>
                            </div>
                            <div class="post_title">
                                <a href="#" title="">Students work together to solve a problem.</a>
                                <div class="post-date">
                                    <span>25 August, 2019</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="archives widget_single">
                        <div class="items-title">
                            <h3 class="title">All Categories</h3>
                        </div>
                        <div class="archives-items">
                            <ul class="list-unstyled">
                                <li><a href="#" title=""><span>Art & Design</span> <span>02</span></a> </li>
                                <li><a href="#" title=""><span>Busness</span><span>05</span></a></li>
                                <li><a href="#" title=""><span>IT & Software</span><span>05</span></a></li>
                                <li><a href="#" title=""><span>Languages</span><span>05</span></a></li>
                                <li><a href="#" title=""><span>Programming</span><span>05</span></a></li>                                
                                <li><a href="#" title=""><span>Technology</span><span>05</span></a></li>
                            </ul>
                        </div>
                    </div>  

                    <div class="popular_tags widget_single">
                        <div class="items-title">
                            <h3 class="title">Popular Tags</h3>
                        </div>
                        <div class="tags-items">
                            <ul class="list-unstyled">
                                <li><a href="#" title="">Travel</a></li>
                                <li><a href="#" title="">Amazing</a></li>
                                <li><a href="#" title="">Clean</a></li>
                                <li><a href="#" title="">Responsive</a></li>
                                <li><a href="#" title="">Room</a></li>
                                <li><a href="#" title="">Travel Tips</a></li>
                                <li><a href="#" title="">Tour</a></li>
                                <li><a href="#" title="">Design</a></li>
                            </ul>
                        </div>
                    </div>  
                </div>
            </div><!-- ./ End  Blog Right Wrapper-->
            
        </div>
    </div> 
</section><!-- ./ End  Blog Wrapper-->

    

<?php include ('footer.php');?> <!-- end footer -->

<div class="to-top pos-rtive">
    <a href="#"><i class = "fa fa-angle-up"></i></a>
</div><!-- Scroll to top-->

    <!-- ============================
            JavaScript Files
    ============================= -->

    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.0.min.js"></script>
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>  
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- owl.carousel js -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- slick js -->
    <script src="js/slick.min.js"></script>
    <!-- meanmenu js -->
    <script src="js/jquery.meanmenu.min.js"></script>
    <!-- jquery-ui js -->
    <script src="js/jquery-ui.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- counter js -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- Countdown js -->
    <script src="js/jquery.countdown.min.js"></script>
    <!-- waypoints js -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- Isotope js -->
    <script src="js/isotope.pkgd.min.js"></script>
    <!-- magnific js -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Image loaded js -->
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- chossen js -->
    <script src="js/chosen.jquery.min.js"></script>
    <!-- Jquery plugin -->
    <script src="js/plugins.js"></script>
    <!-- select2 js plugin -->
    <script src="js/select2.min.js"></script>    
    <script src="js/colors.js"></script>
    <!-- Jquery plugin -->
    <script src="js/jquery-customselect.js"></script>
    <!-- main js -->
    <script src="js/custom.js"></script>
</body>

<!-- Mirrored from ecologytheme.com/theme/travelstar/blog-version-one.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:34:04 GMT -->
</html>
