<!DOCTYPE html>
<html class="no-js" lang="zxx">

<!-- Mirrored from ecologytheme.com/theme/travelstar/single-package.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:33:36 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="TravelStar - Tour, Travel, Travel Agency Template">
    <meta name="keywords" content="Tour, Travel, Travel Agency Template">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelStar - Tour, Travel & Travel Agency Template</title>
    <!-- Google Fonts Includes -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <!-- Favi icon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/images/favicon.ico">
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="css/assets/bootstrap.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="css/assets/animate.css">
    <!-- Button Hover animate css -->
    <link rel="stylesheet" href="css/assets/hover-min.css">
    <!-- jquery-ui.min css -->
    <link rel="stylesheet" href="css/assets/jquery-ui.min.css">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="css/assets/meanmenu.min.css">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="css/assets/owl.carousel.min.css">
    <!-- slick css -->
    <link rel="stylesheet" href="css/assets/slick.css">
    <!-- chosen.min-->
    <link rel="stylesheet" href="css/assets/jquery-customselect.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="css/assets/font-awesome.min.css">
    <!-- magnific Css -->
    <link rel="stylesheet" href="css/assets/magnific-popup.css">
    <!-- Preloader css -->
    <link rel="stylesheet" href="css/assets/preloader.css"> 
    <!-- custome css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/master.css">
    <!-- modernizr css -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>

    <style>
table {
    width:100%;
}
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 15px;
    text-align: left;
}
table#t01 tr:nth-child(even) {
    background-color: #eee;
}
table#t01 tr:nth-child(odd) {
   background-color: #fff;
}
table#t01 th {
    background-color: black;
    color: white;
}
</style>




</head>
<body>
<div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- header area start here -->
<!-- header area start here -->
<?php include ('header.php');?>
<!-- header area end here -->
 <!-- header area end here -->

    <!-- blog breadcrumb version one strat here -->
    <section class="breadcrumb-blog-version-one">
        <div class="single-bredcurms" style="background-image:url('images/bercums/package-Version-01.jpg');">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="bredcrums-content">
                            <h2>About</h2>
                            <!-- <ul>
                                <li><a href="home.php">Home</a>
                                </li>
                                <li class="active"><a href="home.php">About</a>
                                </li>
                            </ul> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- blog breadcrumb version one end here -->

    <section class="section-paddings single-package-area">
        <div class="container">
            <div class="row">
                <!-- single package tab with details -->
                <div class="col-md-12 col-sm-12">
                    <div class="single-package-details">
                        <div class="single-package-title">
                            <h2>About– Health Wealth Card</h2>
                        </div>
                        <!-- <ul class="package-content d-flex justify-content-between">
                            <li>4 Days, 5 Nights</li> -->
                            <!-- <li>
                                <span>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                                   <i class="fa fa-star"></i>
                               </span>
                            </li> -->
                        </ul>
                    </div><!-- tab menu strat -->
                    <div class="package_banner">
                        <img src="images/blog/blog-single.jpg"allowfullscreen alt="" class="img-fluid">
                    </div>
                    <div class="package-tab-menu">
                        <ul class="package-tab-menu nav nav-tabs" id="myTab2" role="tablist">
                            <li role="presentation"><a href="#description" class="active" aria-controls="description" role="tab" data-toggle="tab">Description</a></li>
                            <li role="presentation"><a href="#itinerary" aria-controls="itinerary" role="tab" data-toggle="tab">Tour Guide</a></li>
                            <li role="presentation"><a href="#video" aria-controls="video" role="tab" data-toggle="tab">Additional Features</a></li>
                            <li role="presentation"><a href="#reviews" aria-controls="reviews" role="tab" data-toggle="tab">Mission</a></li>
                        </ul>
                    </div><!-- tab menu end -->

                    <!-- tab content start -->
                    <div class="row">
                        <!-- tabs content -->
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane fade show active in" id="description">
                                <div class="row">
                                    <!-- left content -->
                                    <div class="col-md-12 col-sm-12">
                                        <div class="tour-description">
                                            <p>Health Wealth Card is committed to providing an extraordinary perspective for providing next level of Consumer Services in Healthcare Sector in India. 
Health Wealth Card is only product in India that covers entire spectrum of Healthcare Services ranging from Hospitals, Clinics, Diagnostic Centers and Pharmacies and provides discounts ranging from 10%-50% on these services. 
Not only generic services, Health Wealth Card aims at providing all sort of services to every sector of society. We have Multispecialty Hospitals as well as Specialist Doctors from various fields associated with us providing better Healthcare Services at affordable prices. 
Health Wealth card is not insurance, and therefore doesn't have to restrict users based on health conditions or other situations. 
With Health Wealth discount card, individuals can take the card to one of the participating network in India in order to receive discount on health care services.We have agreement with the Hospitals,Clinic,Diagnostic Center,Pathlab and Pharmacies.Because of these agreements, anytime a cardholder brings a Health Wealth discount card into a participating network, the authorized discount is automatically applied to that bill.</p>
                                        </div>
                                        <!-- <div class="chosse-packge">
                                            
                                            <div class="row">
                                                <div class="col-12 col-md-12 col-sm-12">
                                                    <div class="packaging_contents_wrapper">
                                                        <h4>Additional Info</h4>
                                                        <div class="packaging-contents">
                                                            <ul class="list-unstyled">
                                                                <li><span><i class="fa fa-map-marker"></i>Location</span><span>Thailand</span></li>
                                                                <li><span><i class="fa fa-clock-o"></i>Duration</span><span>4 Days</span></li>
                                                                <li><span><i class="fa fa-user"></i>Min Age</span><span>12+</span></li>
                                                                <li><span><i class="fa fa-users"></i>Max People</span><span>05</span></li>
                                                            </ul>
                                                            <ul class="list-unstyled">
                                                                <li><span><i class="fa fa-plane"></i>Landing</span><span>Thailand</span></li>
                                                                <li><span><i class="fa fa-calendar-check-o"></i>Check In</span><span>15/05/2019</span></li>
                                                                <li><span><i class="fa fa-calendar-minus-o"></i>Check Out</span><span>15/06/2019</span></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div><!-- left-content -->

                                </div>
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="itinerary">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="tour-description">
                                            <h4>Benefits</h4>
                                            <!-- <div class="main-timeline"> -->
                                            <h3 class="block-head">Benifits of Health Wealth Card.</h3>
	<p> No processing  fee,  only  one	   time	   annual	   subscription	   Model  at  time  of  purchasing  card  i.e.  INR 299/499	   &	   999	   only.	</br>  
No long procedures to avail discount, simply walk in and display your card at Billing Counter to avail discount.</br>	   
No wastage of time in searching for respective Doctors or Hospitals, simply visit  <a href="www.healthwealthcard.com">www.healthwealthcard.com</a>  and  search  for  Healthcare  services  in  your vicinity according to your budget and specialization</br>	   
One Health Wealth Card is valid for a single person for a	   period	   of	   1	   year. With  the  help  of  Newsroom  Section,  users  can  check  upcoming  Health	   
Camps in their areas.</br>   
Single card is valid across the nation. In case you visit some other city and go through health issues, simply check for Health Wealth Card associated Doctors on our website.
</p>
                                                <!-- single timeline -->
                                                <!-- <div class="timeline">
                                                    <div class="timeline-content left">
                                                        <span class="timeline-icon">1</span>
                                                        <h4>Day 1: Meeting The All Members</h4>
                                                        <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight Japan Tripit territory international carren tal Pacific outdoor Turkey. Country international to urist attractions mil es train Moscow guide. Japan horse riding money Bacel ona Buda pest yach.</p>
                                                    </div>
                                                </div><!-- single timeline -->

                                                <!-- single timeline -->
                                                <!-- <div class="timeline">
                                                    <div class="timeline-content left">
                                                        <span class="timeline-icon">2</span>
                                                        <h4>Day 2: Unforgettable Journey</h4>
                                                        <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
                                                    </div>
                                                </div>single timeline -->

                                                <!-- single timeline -->
                                                <!-- <div class="timeline">
                                                    <div class="timeline-content left">
                                                        <span class="timeline-icon">3</span>
                                                        <h4>Day 3: Night Party</h4>
                                                        <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
                                                    </div>
                                                </div>single timeline -->

                                                <!-- single timeline -->
                                                <!-- <div class="timeline">
                                                    <div class="timeline-content left">
                                                        <span class="timeline-icon">4</span>
                                                        <h4>Day 4: Time To Say Good Bay</h4>
                                                        <p>Tourist attractions people foreign sleep overnight housing. Gerimrany group discount tour operator. Airplane couchsurfing Moi scow ma ps uncharted luxury train guest tour operator German y busre laxation. Paris overnight.</p>
                                                    </div>
                                                </div>single timeline -->
                                            <!-- </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="reviews">
                                <div class="row">
                                    <div class="col-12 col-md-12 col-sm-12">
                                        <div class="tour-description">
                                            <h4>Mission</h4>
                                           <p>Health Wealth Card works behind the ideology of “स्वस्थ भारत, समृद्ध भारत” . At Health Wealth Card, we believe that it’s right of every citizen of our country to get better treatment in their budget and it must be easily accessible without any hidden Terms or Conditions. 
The only mission of Health Wealth Card is to make Healthcare Services available across the Nation at affordable prices, making them feasible and in reach of every sector of society.
Health Wealth Card is a unique product with each card having its unique number that helps in solving all the problems faced by people..</p>
                                            <!-- Video -->
                                            <!-- <div class="tab-video-area video-bg">
                                                <div class="video-play-btn">
                                                    <a href="https://www.youtube.com/watch?v=L0K0AYRFZQI" class="video_iframe"><span><i class="fa fa-play"></i></span></a>
                                                </div>
                                            </div>Video -->
                                        </div>
                                    </div>
                                </div>
                            </div><!-- video tab content end -->


                            <!-- video tab content start -->
                            <div role="tabpanel" class="tab-pane fade" id="video">
                                <div class="row">
                                    <div class="col-12 col-md-12 col-sm-12">
                                        <div class="tour-description">
                                            <h4>Additional Features And Benefits</h4>
                                           <p>We	are	introducing	Pre-­‐	Approved	Immediate	Medical	Loan	facility	(IML)	having	business	Tie-­‐	ups	with various	Financers	of	the	nation	at	a	very	lowest	Interest	rates	feasible.	Along	with	that	we	are	also	providing Personal	Accidental	insurance	upto	1	Lakh	or	as	per	the	subscription	Model	at	a	very	nominal	premium covered	upto	a	period	of	1	year.	Aside	of	this	we	are	also	looking	to	provide	individual	Disease	wise	cover	to almost	certain	amount	Aside	of	this	the	existing	USP	of	availing	discount	from	10%	-­‐	50%	is	already	an added	advantage.	As	a	part	of	the	Insurance	facility	we	also	look	forward	to	Have	the	loan	amount	being insured	just	if	in	case.</p>
                                           <table id="t01">
  <tr>
    <th>Annual Subscripition Model </th>
    <th> pre-- approved <br>IML Amount</br></th> 
  </tr>
  <tr>
    <td><b>INR 299</b></td>
    <td><b>50,000 INR</b></td>
  </tr> 
  <tr>
    <td><b> INR 499</b></td>
    <td><b>1,00,000 INR</b></td>
  </tr>
  <tr>
    <td><b>INR 999</b></td>
    <td><b>2,00,000 INR</b></td>
  </tr>
</table>

                                            
                                            
                                            
                                            
                                            <!-- Video -->
                                            <!-- <div class="tab-video-area video-bg">
                                                <div class="video-play-btn">
                                                    <a href="https://www.youtube.com/watch?v=L0K0AYRFZQI" class="video_iframe"><span><i class="fa fa-play"></i></span></a>
                                                </div>
                                            </div>Video -->
                                        </div>
                                    </div>
                                </div>
                            </div><!-- video tab content end -->

                            <!-- video tab content start -->
                            <!-- <div role="tabpanel" class="tab-pane fade" id="reviews">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="tour-description">
                                             <div class="comment-list-items">
                                                <div class="comment-list-wrapper">
                                                    <div class="comment-list">
                                                        <div class="commnet_img">
                                                            <img src="images/blog/comments1.jpg" alt="member img" class="img-fluid">
                                                        </div>
                                                        <div class="comment-text">
                                                            <div class="author_info"> 
                                                                <div class="author_name">
                                                                    <a href="#" class="">Adam Smith</a> 
                                                                    <span>20 July 2019 at 10.45 AM</span>
                                                                 </div>
                                                                 <div class="reply-comment">
                                                                    <a href="#" title=""> <i class="flaticon-reply-arrow"></i> Reply</a>
                                                                </div> 
                                                            </div> 
                                                            <ul class="review_rating d-flex">
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                            </ul>    
                                                            <p>You need to be sure there isn't anything embarrassing hidden in the repeat predefined chunks as nessing hidden in the repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                                                        </div>
                                                    </div>

                                                    <div class="comment-list reply_comment_text">
                                                        <div class="commnet_img">
                                                           <img src="images/blog/comments2.jpg" alt="member img" class="img-fluid">
                                                        </div>
                                                        <div class="comment-text">
                                                            <div class="author_info"> 
                                                                <div class="author_name">
                                                                    <a href="#" class="">Jonson Park</a> 
                                                                    <span>20 July 2019 at 10.45 AM</span>
                                                                 </div>
                                                                 <div class="reply-comment">
                                                                    <a href="#" title=""> <i class="flaticon-reply-arrow"></i> Reply</a>
                                                                </div> 
                                                            </div>
                                                            <ul class="review_rating d-flex">
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                            </ul>         
                                                            <p>You need to be sure there isn't anything embarrassing hidden in the repe essary, making this the first true generator on the Internet.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="comment-list-wrapper">
                                                    <div class="comment-list">
                                                        <div class="commnet_img">
                                                            <img src="images/blog/comments1.jpg" alt="member img" class="img-fluid">
                                                        </div>
                                                        <div class="comment-text">
                                                            <div class="author_info"> 
                                                                <div class="author_name">
                                                                    <a href="#" class="">Jonathon Smith</a> 
                                                                    <span>20 July 2019 at 10.45 AM</span>
                                                                 </div>
                                                                 <div class="reply-comment">
                                                                    <a href="#" title=""> <i class="flaticon-reply-arrow"></i> Reply</a>
                                                                </div> 
                                                            </div>
                                                            <ul class="review_rating d-flex">
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                                <li><i class="fa fa-star"></i></li>
                                                            </ul>         
                                                            <p>You need to be sure there isn't anything embarrassing hidden in the repeat predefined chunks as nessing hidden in the repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
                                                        </div>                               
                                                    </div>
                                                </div>
                                            </div> 
                                        </div>
                                    </div>
                                </div>
                            </div>video tab content end -->
                        </div><!-- tabs content-->
                    </div><!-- tab content end -->
                </div><!-- single package tab with details -->

                <!-- booking form start here -->
                <!-- <div class="col-md-4 col-sm-12">
                    <aside>
                        <div class="booking-form">
                            <div class="booking-title">
                                <h2>Book This Tour</h2>
                                <p>Lorem ipsum dolor sit amet, consectet ur adipiscing elit, sedpr do eiusmod tempor incididunt ut.</p>
                            </div>
                            <form action="#" method="post">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="name" placeholder="Name">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="confirm_email" placeholder="E-mail">
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="form-control" id="number" placeholder="Phone Number">
                                </div>
                                <div class="form-group">
                                    <textarea name="messgae" id="message" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
                                </div>
                                <div class="form-group form_btn">
                                    <button type="submit" class="booking-confirm hvr-shutter-out-horizontal">Book Now</button>
                                </div>
                            </form>
                        </div>
                    </aside> adverestment start here-->

                    <!-- <div class="adding-form">
                        <div class="addfor-bg">
                            <div class="add-content">
                                <h3>Get A Question!</h3>
                                <p>Lorem ipsum dolor sit amet, consectet ur adipiscing elit, sedpr do eiusmod tempor incididunt ut.</p>
                                <ul class="contact-for-add">
                                    <li><img src="images/icon/phone.png" alt="">+123-456-7890</li>
                                    <li><img src="images/icon/gmail.png" alt="">info@yourcompany.com</li>
                                </ul>
                            </div>
                        </div>
                    </div>adverestment start here -->
                <!-- </div> -->
            </div>
        </div>
    </section>

<!-- realted tour start here -->
<section class="our_partners">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-title text-center">
                    <h2>Our Trusted Partners</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- partners images -->
            <div class="partner-slider-active owl-carousel">
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/1.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/2.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/3.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/2.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/5.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- partners images -->
        <div class="row">
            <!-- partners images -->
            <div class="partner-slider-active owl-carousel">
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/1.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/2.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/3.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/2.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="single-pertner">
                    <div class="partner-image">
                        <a href="#"><img src="images/partner/5.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>  <!-- end partners images -->
    </div>
</section> 

    <?php include ('footer.php');?> <!-- end footer -->

<div class="to-top pos-rtive">
    <a href="#"><i class = "fa fa-angle-up"></i></a>
</div><!-- Scroll to top-->
    <!-- ============================
            JavaScript Files
    ============================= -->
    
    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.0.min.js"></script>
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>  
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- owl.carousel js -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- slick js -->
    <script src="js/slick.min.js"></script>
    <!-- meanmenu js -->
    <script src="js/jquery.meanmenu.min.js"></script>
    <!-- jquery-ui js -->
    <script src="js/jquery-ui.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- counter js -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- Countdown js -->
    <script src="js/jquery.countdown.min.js"></script>
    <!-- waypoints js -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- Isotope js -->
    <script src="js/isotope.pkgd.min.js"></script>
    <!-- magnific js -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Image loaded js -->
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- chossen js -->
    <script src="js/chosen.jquery.min.js"></script>  
    <!-- Jquery plugin -->
    <script src="js/plugins.js"></script>
    <!-- select2 js plugin -->
    <script src="js/select2.min.js"></script>    
    <script src="js/colors.js"></script>
    <!-- Jquery plugin -->
    <script src="js/jquery-customselect.js"></script>
    <!-- google map api -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIW0B_E3g-Yg533xy3yF0WHThi-mFvSNQ"></script>
    <!-- map js -->
    <script src="js/google-map.js"></script>
    <!-- main js -->    
    <script src="js/custom.js"></script>
</body>

<!-- Mirrored from ecologytheme.com/theme/travelstar/single-package.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:33:46 GMT -->
</html>
