<!DOCTYPE html>
<html class="no-js" lang="zxx">

<!-- Mirrored from ecologytheme.com/theme/travelstar/index-4.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:32:33 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="TravelStar - Tour, Travel, Travel Agency Template">
    <meta name="keywords" content="Tour, Travel, Travel Agency Template">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelStar - Tour, Travel & Travel Agency Template</title>
    <!-- Google Fonts Includes -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
    <!-- Favi icon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/images/favicon.ico">
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="css/assets/bootstrap.min.css">
    <!-- animate css -->
    <link rel="stylesheet" href="css/assets/animate.css">
    <!-- Button Hover animate css -->
    <link rel="stylesheet" href="css/assets/hover-min.css">
    <!-- jquery-ui.min css -->
    <link rel="stylesheet" href="css/assets/jquery-ui.min.css">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="css/assets/meanmenu.min.css">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="css/assets/owl.carousel.min.css">
    <!-- slick css -->
    <link rel="stylesheet" href="css/assets/slick.css">
    <!-- chosen.min-->
    <link rel="stylesheet" href="css/assets/jquery-customselect.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="css/assets/font-awesome.min.css">
    <!-- magnific Css -->
    <link rel="stylesheet" href="css/assets/magnific-popup.css">
    <!-- Revolution Slider -->
    <link rel="stylesheet" href="css/assets/revolution/layers.css">
    <link rel="stylesheet" href="css/assets/revolution/navigation.css">
    <link rel="stylesheet" href="css/assets/revolution/settings.css">
    <!-- Preloader css -->
    <link rel="stylesheet" href="css/assets/preloader.css"> 
    <!-- custome css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- responsive css -->
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/master.css">
    <link rel="stylesheet" href="css/master.css">
    <!-- modernizr css -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>
<div id="loader-wrapper">
    <div id="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- header area start here -->
<?php include ('header.php');?>
<!-- header area end here -->
 <!-- header area end here -->

    <!-- slider area start here -->
    <section class="slider-area-2 slider-area-3">
        <div class="rev_slider_wrapper">
            <div id="rev_slider_4" class="rev_slider" style="display:none">
                <!-- BEGIN SLIDES LIST -->
                <ul>
                    <!-- first slider -->
                   <li data-transition="random-premium" data-title="Slide Title" data-param1="Additional Text" data-thumb="images/slider/slider_4_1.jpg">
                        <!-- SLIDE'S MAIN BACKGROUND IMAGE -->
                        <img src="images/slider/slider_4_1.jpg"  alt=""  data-bgposition="center center" data-kenburns="on" data-duration="10000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 -500" data-offsetend="0 500" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        <div class="image-overlay"></div>
                        <!-- BEGIN BASIC TEXT LAYER -->
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption sfr font-extra-bold tp-resizeme letter-space-4 title-line-4" data-x="['left', 'left', 'left', 'left']" data-hoffset="0" data-y="center" data-voffset="-120" data-frames='[{"delay":0,"speed":3000,"frame":"0","from":"x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]' style="z-index: 6; color:#fff; font-family:'Poppins', sans-serif; white-space: nowrap; font-weight:700;">
                            <h2 style="font-size:60px; line-height: 65px;">Special Offer</h2>

                        </div>

                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption sfr font-extra-bold tp-resizeme letter-space-4 title-line-42" data-x="left" data-hoffset="0" data-y="center" data-voffset="-60" data-frames='[{"delay":1000,"speed":3000,"frame":"0","from":"x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]' style="z-index: 6; font-size:16px; color:#fff; text-transform:capitalize; font-family:'Poppins', sans-serif; white-space: nowrap; font-weight:400;">
                            <h3>7 Days in Eangland Tour Start From<span>$250</span></h3>
                        </div>
                        <!-- LAYER NR. 4 -->
                        <div class="tp-caption font-lora sfb tp-resizeme letter-space-5 header-p4" data-x="left" data-hoffset="0" data-y="center" data-voffset="0" data-frames='[{"delay":1000,"speed":3000,"frame":"0","from":"x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'  style="z-index: 7; font-size:15px; color:#fff; font-family:'Poppins', sans-serif; max-width: auto; max-height: auto; white-space: nowrap; font-weight:400;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod
                        </div>

                        <!-- LAYER NR. 5 -->
                        <div class="tp-caption font-lora sfb tp-resizeme letter-space-5 header-p44" data-x="left" data-hoffset="0" data-y="center" data-voffset="30" data-frames='[{"delay":1000,"speed":3000,"frame":"0","from":"x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]' style="z-index: 7; font-size:15px; color:#fff; font-family:'Poppins', sans-serif; max-width: auto; max-height: auto; white-space: nowrap; font-weight:400;">
                            tempor incididunt ut labore et dolore magna aliqua.
                        </div>

                       <!-- LAYER NR. 6 -->
                        <div class="tp-caption lfb tp-resizeme header-btn-4" data-x="left" data-hoffset="0" data-y="center" data-voffset="120" data-frames='[{"delay":0,"speed":2000,"frame":"0","from":"y:bottom;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]' style="z-index: 8;"><a href="#" class="travel-primary-btn hvr-shutter-out-vertical">Start Tour</a>
                    </li>
                    <!-- end first slider -->
                   <!-- first slider -->
                    <li data-transition="random-premium" data-title="Slide Title" data-param1="Additional Text" data-thumb="images/slider/slider_4_2.jpg">
                        <!-- SLIDE'S MAIN BACKGROUND IMAGE -->
                        <img src="images/slider/slider_4_2.jpg"  alt=""  data-bgposition="center center" data-kenburns="on" data-duration="10000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="120" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 -500" data-offsetend="0 500" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        <div class="image-overlay"></div>
                        <!-- BEGIN BASIC TEXT LAYER -->
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption sfr font-extra-bold tp-resizeme letter-space-4 title-line-4" data-x="['left', 'left', 'left', 'left']" data-hoffset="0" data-y="center" data-voffset="-120" data-frames='[{"delay":0,"speed":3000,"frame":"0","from":"x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]' style="z-index: 6; color:#fff; text-transform:uppercase; font-family:'Poppins', sans-serif; white-space: nowrap; font-weight:600;">
                            <h2 style="font-size:50px;">Special Offer</h2>

                        </div>

                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption sfr font-extra-bold tp-resizeme letter-space-4 title-line-42" data-x="left" data-hoffset="0" data-y="center" data-voffset="-70" data-frames='[{"delay":1000,"speed":3000,"frame":"0","from":"x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]' style="z-index: 6; font-size:25px; color:#fff; text-transform:capitalize; font-family:'Poppins', sans-serif; white-space: nowrap; font-weight:400;">
                            <h3>7 Days in Eangland Tour Start From<span>$250</span></h3>
                        </div>
                        <!-- LAYER NR. 4 -->
                        <div class="tp-caption font-lora sfb tp-resizeme letter-space-5 header-p4" data-x="left" data-hoffset="0" data-y="center" data-voffset="0" data-frames='[{"delay":1000,"speed":3000,"frame":"0","from":"x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[-100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'  style="z-index: 7; font-size:15px; color:#fff; font-family:'Poppins', sans-serif; max-width: auto; max-height: auto; white-space: nowrap; font-weight:400;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod
                        </div>

                        <!-- LAYER NR. 6 -->
                        <div class="tp-caption lfb tp-resizeme header-btn-4" data-x="left" data-hoffset="0" data-y="center" data-voffset="120" data-frames='[{"delay":0,"speed":2000,"frame":"0","from":"y:bottom;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]' style="z-index: 8;"><a href="#" class="travel-primary-btn hvr-shutter-out-vertical">Start Tour</a>
                        </div>
                    </li><!-- end first slider -->
                </ul><!-- END SLIDES LIST -->
            </div><!-- END SLIDER CONTAINER -->
        </div><!-- END SLIDER CONTAINER WRAPPER -->
    </section><!-- slider area end here -->

<section class="search_area search_area_4" id="search_area_2">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-12">
                <div class="search_form">
                    <form action="#" method="post">
                        <div class="form_wrapper">
                            <div class="form-group">
                                <label><i class="fa fa-map-marker"></i></label>
                                <input type="text" name="s" id="keyword2" class="hotel-input-first" placeholder="Type Keyword">
                            </div>
                            <div class="form-group">
                                <label><i class="fa fa-calendar"></i></label>
                                <input type="text" name="s" id="datepicker2" class="hotel-input-first" placeholder="Check-In Date">
                            </div>
                            <div class="form-group">
                                <label><i class="fa fa-user"></i></label>
                                <input type="number" name="s" id="number1" class="hotel-input-first" placeholder="Number of Guest">
                            </div>
                            <div class="searc-btn-7">
                                <button type="submit">Search</button>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</section> <!-- header tab based search area end-->



<section class="popular-packages popular_packages_4" id="popular_packages_3">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-title">
                    <h2>Our Most Popular Packges</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/1.jpg" alt=""></a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Dubai – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/2.jpg" alt=""></a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Thailand – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/3.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">England – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/4.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Italy – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/5.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">Brazil – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                <div class="single-package">
                    <div class="package-image">
                        <a href="#"><img src="images/packages/6.jpg" alt="">
                        </a>
                    </div>
                    <div class="package-content">
                        <h3><a href="#" title="">India – All Stunning Places</a></h3>
                        <p>4 Days, 5 Nights Start From <span>$500</span>
                        </p>
                    </div>
                    <div class="package-calto-action">
                        <ul class="ct-action">
                            <li><a href="#" class="travel-booking-btn hvr-shutter-out-horizontal">Book Now</a>
                            </li>
                            <li>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> <!-- single package end -->
        </div>
    </div>
</section> <!--end  popular packajge -->



<!-- dicount package 4 -->
<section class="discount-package-4">
    <div class="container-fluid p-0">
        <div class="row ml-auto">
            <div class="col-sm-6 col-md-6 p-0">
                <div class="discount_banner">
                    <img src="images/bgimage/dis_4.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
    <div class="discount_banner_details">
        <div class="container">
            <div class="row ml-auto">
                <div class="col-sm-6 col-md-6 ml-auto">
                    <div class="discount-package-4-contents">
                        <div class="discount-package-4-title">
                            <h2>Special Discount <span>20-30% off</span></h2>
                            <p>Lorem ipsum dolor sit ameit, consectetuer adipiscing elity sed your diam nonummy nibh euismody tincidunt utyou laoreet dolore magn aliquam erat volutpat. Ut wisi yuo tation ullamcorperea commodo con....</p>
                             <a href="#" class="travel-primary-btn-2">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dicount package 4 -->

    <!-- top destination start here -->
    <section class="top-destination-area pt-100 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title text-center">
                        <h2>Top Destination</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- single destination -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <figure>
                        <a href="#"><img src="images/destination/france.jpg" alt="">
                        </a>
                        <figcaption>
                            <h4><a href="#" title="">France</h4>
                        </figcaption>
                    </figure>
                </div>
                <!-- single destination -->
                <!-- single destination -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <figure>
                        <a href="#"><img src="images/destination/america.jpg" alt="">
                        </a>
                        <figcaption>
                            <h4><a href="#" title="">America</h4>
                        </figcaption>
                    </figure>
                </div>
                <!-- single destination -->
                <!-- single destination -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <figure>
                        <a href="#"><img src="images/destination/india.jpg" alt="">
                        </a>
                        <figcaption>
                            <h4><a href="#" title="">India</a></h4>
                        </figcaption>
                    </figure>
                </div>
                <!-- single destination -->
                <!-- single destination -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <figure>
                        <a href="#"><img src="images/destination/india.jpg" alt="">
                        </a>
                        <figcaption>
                            <h4><a href="#" title="">Itilay</a></h4>
                        </figcaption>
                    </figure>
                </div>
                <!-- single destination -->
                <!-- single destination -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <figure>
                        <a href="#"><img src="images/destination/eng.jpg" alt="">
                        </a>
                        <figcaption>
                            <h4><a href="#" title="">England</a></h4>
                        </figcaption>
                    </figure>
                </div>
                <!-- single destination -->
                <!-- single destination -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <figure>
                        <a href="#"><img src="images/destination/bragil.jpg" alt="">
                        </a>
                        <figcaption>
                            <h4><a href="#" title="">Brazil</a></h4>
                        </figcaption>
                    </figure>
                </div>
                <!-- single destination -->
                <!-- single destination -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <figure>
                        <a href="#"><img src="images/destination/thaland.jpg" alt="">
                        </a>
                        <figcaption>
                            <h4><a href="#" title="">Thailand</a></h4>
                        </figcaption>
                    </figure>
                </div>
                <!-- single destination -->
                <!-- single destination -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <figure>
                        <a href="#"><img src="images/destination/spain.jpg" alt="">
                        </a>
                        <figcaption>
                            <h4><a href="#" title="">Spain</a></h4>
                        </figcaption>
                    </figure>
                </div>
                <!-- single destination -->
            </div>
        </div>
    </section>
    <!-- top destination end here -->

    <!-- Our Achievment start here -->
    <section class="achievment-bg image-bg-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title-white text-center mbt-100">
                        <h2>Our Achievment</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-xs-12 col-md-12 col-sm-12">
                    <!-- counter setup -->
                    <div class="single-counter-box">
                        <div class="single-counter">
                            <div class="counter-image">
                                <img src="images/icon/trousit.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <div class="counter">8500</div>
                                <span>Tourists</span>
                            </div>
                        </div>

                        <div class="single-counter">
                            <div class="counter-image">
                                <img src="images/icon/2.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <div class="counter">2500</div>
                                <span>Destinations</span>
                            </div>
                        </div>

                        <div class="single-counter">
                            <div class="counter-image">
                                <img src="images/icon/3.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <div class="counter">200</div>
                                <span>Safe Flight</span>
                            </div>
                        </div>

                        <div class="single-counter">
                            <div class="counter-image">
                                <img src="images/icon/4.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <div class="counter">7000</div>
                                <span>Happy Clients</span>
                            </div>
                        </div>

                        <div class="single-counter">
                            <div class="counter-image">
                                <img src="images/icon/5.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <div class="counter">6500</div>
                                <span>Tour</span>
                            </div>
                        </div>
                    </div>
                    <!-- counter setup -->
                </div>
            </div>
        </div>
    </section>
    <!-- Our Achievment end here -->

<!-- We Recommend Hotels start here -->
<div class="hotels-area pt-100 pb-75">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title text-center">
                    <h2>We Recommend Hotels</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- single hotels -->
            <div class="col-12 col-sm-6 col-md-6 col-lg-4 co-lxs-12">
                <div class="single-hotels">
                    <div class="hotel-image">
                        <img src="images/hotel/1.jpg" alt="" class="border-raduis-3">
                    </div>
                    <div class="hotel-description">
                        <h4>Sheraton Hotel</h4>
                        <p>Start from <span>$50/</span>Per Nights 2 Person</p>
                        <div class="hotel-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="hotet-book-btn">
                            <a href="#" class="travel-primary-btn hvr-shutter-out-horizontal">Show Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- single hotels -->
            <!-- single hotels -->
            <div class="col-12 col-sm-6 col-md-6 col-lg-4 co-lxs-12">
                <div class="single-hotels">
                    <div class="hotel-image">
                        <img src="images/hotel/2.jpg" alt="" class="border-raduis-3">
                    </div>
                    <div class="hotel-description">
                        <h4>Daydream Hotel</h4>
                        <p>Start from <span>$50/</span>Per Nights 2 Person</p>
                        <div class="hotel-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="hotet-book-btn">
                            <a href="#" class="travel-primary-btn hvr-shutter-out-horizontal">Show Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- single hotels -->
            <!-- single hotels -->
            <div class="col-12 col-sm-6 col-md-6 col-lg-4 co-lxs-12">
                <div class="single-hotels">
                    <div class="hotel-image">
                        <img src="images/hotel/3.jpg" alt="" class="border-raduis-3">
                    </div>
                    <div class="hotel-description">
                        <h4>Scarlet Lagoon Hotel</h4>
                        <p>Start from <span>$50/</span>Per Nights 2 Person</p>
                        <div class="hotel-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="hotet-book-btn">
                            <a href="#" class="travel-primary-btn hvr-shutter-out-horizontal">Show Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- single hotels -->
        </div>
    </div>
</div>
<!-- We Recommend Hotels end here -->




<!-- guide and Expert Advice strat -->
<section class="section-paddings" id="blog_4">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-title text-center">
                    <h2>Travel guide and Expert Advice</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- single travel blog-->
            <div class="col-12 col-sm-6 col-md-6 col-lg-4 phone-layout-s">
                <div class="single-travel-blog">
                    <div class="blog-image">
                        <a href="#"><img src="images/blog/1.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">
                            <div class="post-date">
                                <span>12 July, 2019</span>
                            </div>
                            <ul class="post-social">
                                <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                </li>
                                <li><a href="#"><i class="fa fa-heart-o"></i>43</a>
                                </li>
                            </ul>
                        </div>
                        <div class="blog-post-content">
                            <h4><a href="#" title="">Tips for taking a long-term trip with kids.</a></h4>
                            <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div> <!--end single travel guide & security-->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4 phone-layout-s">
                <div class="single-travel-blog">
                    <div class="blog-image">
                        <a href="#"><img src="images/blog/2.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">
                            <div class="post-date">
                                <span>12 July, 2019</span>
                            </div>
                            <ul class="post-social">
                                <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                </li>
                                <li><a href="#"><i class="fa fa-heart-o active"></i>43</a>
                                </li>
                            </ul>
                        </div>
                        <div class="blog-post-content">
                            <h4><a href="#" title="">Tips for taking a long-term trip with kids.</a></h4>
                            <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div> <!--end single travel guide & security-->

            <div class="col-12 col-sm-6 col-md-6 col-lg-4 phone-layout-s">
                <div class="single-travel-blog">
                    <div class="blog-image">
                        <a href="#"><img src="images/blog/3.jpg" alt="">
                        </a>
                    </div>
                    <div class="blog-content">
                        <div class="blog-meta">
                            <div class="post-date">
                                <span>12 July, 2019</span>
                            </div>
                            <ul class="post-social">
                                <li><a href="#"><i class="fa fa-comments"></i>3</a>
                                </li>
                                <li><a href="#"><i class="fa fa-heart-o"></i>43</a>
                                </li>
                            </ul>
                        </div>
                        <div class="blog-post-content">
                            <h4><a href="#" title="">Tips for taking a long-term trip with kids.</a></h4>
                            <p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus.</p>
                            <a href="#">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div> <!-- single travel guide & security end-->
        </div>
    </div>
</section> <!--End guide and Expert Advice strat -->





    <!-- Our Achievment start here -->
    <section class="experience_4 image-bg-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title-white text-center mbt-100">
                        <h2>Choose Our Experience</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-xs-12 col-md-12 col-sm-12">
                    <!-- counter setup -->
                    <div class="single-counter-box">
                        <div class="single_experience">
                            <div class="counter-image">
                                <img src="images/icon/9.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <h3>History & Culture</h3>
                            </div>
                        </div>

                        <div class="single_experience">
                            <div class="counter-image">
                                <img src="images/icon/10.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <h3>Nature & wildlife</h3>
                            </div>
                        </div>

                        <div class="single_experience">
                            <div class="counter-image">
                                <img src="images/icon/11.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <h3>Adventure Travel </h3>
                            </div>
                        </div>

                        <div class="single_experience">
                            <div class="counter-image">
                                <img src="images/icon/12.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <h3>Beaches & Islands</h3>
                            </div>
                        </div>

                        <div class="single_experience">
                            <div class="counter-image">
                                <img src="images/icon/10.png" alt="">
                            </div>
                            <div class="counter-elements">
                                <h3>Sightseeing tours</h3>
                            </div>
                        </div>
                    </div>
                    <!-- counter setup -->
                </div>
            </div>
        </div>
    </section>
    <!-- Our Achievment end here -->



    <?php include ('footer.php');?> <!-- end footer -->

    <div class="to-top pos-rtive">
        <a href="#"><i class = "fa fa-angle-up"></i></a>
    </div>    <!-- Scroll to top jump button end-->

    <!-- ============================
            JavaScript Files
    ============================= -->

    <!-- jquery latest version -->
    <script src="js/vendor/jquery-3.2.0.min.js"></script>
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>  
    <!-- bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- owl.carousel js -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- slick js -->
    <script src="js/slick.min.js"></script>
    <!-- meanmenu js -->
    <script src="js/jquery.meanmenu.min.js"></script>
    <!-- jquery-ui js -->
    <script src="js/jquery-ui.min.js"></script>
    <!-- wow js -->
    <script src="js/wow.min.js"></script>
    <!-- counter js -->
    <script src="js/jquery.counterup.min.js"></script>
    <!-- Countdown js -->
    <script src="js/jquery.countdown.min.js"></script>
    <!-- waypoints js -->
    <script src="js/jquery.waypoints.min.js"></script>
    <!-- Isotope js -->
    <script src="js/isotope.pkgd.min.js"></script>
    <!-- magnific js -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Image loaded js -->
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- chossen js -->
    <script src="js/chosen.jquery.min.js"></script>
    <script src="js/assets/revolution/jquery.themepunch.revolution.min.js"></script>
    <script src="js/assets/revolution/jquery.themepunch.tools.min.js"></script>
    <!-- Revolution Extensions -->
    <script src="js/assets/revolution/extensions/revolution.extension.actions.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.carousel.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.migration.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.navigation.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.parallax.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.slideanims.min.js"></script>
    <script src="js/assets/revolution/extensions/revolution.extension.video.min.js"></script> 
    <script src="js/assets/revolution/revolution.js"></script>       
    <!-- Jquery plugin -->
    <script src="js/plugins.js"></script>
    <!-- select2 js plugin -->
    <script src="js/select2.min.js"></script>    
    <script src="js/colors.js"></script>
    <!-- Jquery plugin -->
    <script src="js/jquery-customselect.js"></script>
    <!-- main js -->
    <script src="js/custom.js"></script>
</body>

<!-- Mirrored from ecologytheme.com/theme/travelstar/index-4.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2019 10:33:36 GMT -->
</html>
